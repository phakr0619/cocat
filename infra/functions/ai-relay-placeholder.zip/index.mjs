// Placeholder. The real code (server/ai-relay) is uploaded by .github/workflows/deploy-ai-relay.yml.
// Writes before ending, because CloudFront turns an empty streamed response into a 502.
export const handler = awslambda.streamifyResponse(async (_event, responseStream) => {
  const stream = awslambda.HttpResponseStream.from(responseStream, { statusCode: 200, headers: { 'content-type': 'application/json' } });
  stream.write(' ');
  stream.write(JSON.stringify({ ok: false, error: { kind: 'server', message: 'relay code is not deployed yet' } }));
  stream.end();
});
